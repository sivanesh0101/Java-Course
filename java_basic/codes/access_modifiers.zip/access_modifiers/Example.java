package access_modifiers;

public class Example {
    public int num = 10;

    public void show() {
        System.out.println("Public method: num = " + num);
    }
}
